@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m pip install pyinstaller
python -m PyInstaller --noconfirm --onefile --windowed --name "AI Drive Manager" "AI_Drive_Manager_Launcher.pyw"
echo.
echo EXE: dist\AI Drive Manager.exe
echo Copy it to this project root folder.
pause
