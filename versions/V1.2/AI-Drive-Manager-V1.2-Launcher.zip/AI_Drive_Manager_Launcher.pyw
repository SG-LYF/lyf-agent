import os, sys, time, socket, subprocess, threading, webbrowser, tkinter as tk
from tkinter import messagebox
from pathlib import Path

APP_HOST = "127.0.0.1"
APP_PORT = 8000
APP_URL = "http://localhost:8000"

def project_dir():
    return Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent

ROOT = project_dir()
process = None

def port_open():
    try:
        with socket.create_connection((APP_HOST, APP_PORT), timeout=0.6):
            return True
    except OSError:
        return False

def find_python():
    for c in ["python", "py", r"C:\Python314\python.exe", r"C:\Python312\python.exe"]:
        try:
            if os.path.isabs(c):
                if Path(c).exists(): return c
            else:
                subprocess.run([c, "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
                return c
        except Exception:
            pass
    return None

def log(msg):
    logbox.configure(state="normal")
    logbox.insert("end", msg + "\n")
    logbox.see("end")
    logbox.configure(state="disabled")

def set_status(text, ok=False):
    status_var.set(text)
    status_label.configure(fg="#14844a" if ok else "#8a4f00")

def read_output():
    global process
    if process and process.stdout:
        for line in process.stdout:
            root.after(0, log, line.rstrip())

def wait_ready(open_browser=True):
    for _ in range(80):
        if process is not None and process.poll() is not None:
            root.after(0, set_status, "Agent 启动失败")
            return
        if port_open():
            root.after(0, set_status, "Agent 已启动 · 可查询和录入", True)
            root.after(0, log, "Agent 已就绪：http://localhost:8000")
            if open_browser:
                root.after(0, webbrowser.open, APP_URL)
            return
        time.sleep(0.25)
    root.after(0, set_status, "启动超时，请查看日志")

def start_agent(open_browser=True):
    global process
    if port_open():
        set_status("Agent 已运行 · 可查询和录入", True)
        if open_browser: webbrowser.open(APP_URL)
        return
    py = find_python()
    if not py:
        messagebox.showerror("未找到 Python", "请确认 Python 已安装。")
        return
    if not (ROOT / "app" / "main.py").exists():
        messagebox.showerror("项目不完整", f"找不到 app\\main.py。\n请把本启动器放到完整项目根目录：\n{ROOT}")
        return
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen(
        [py, "-m", "uvicorn", "app.main:app", "--host", APP_HOST, "--port", str(APP_PORT)],
        cwd=str(ROOT),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
        creationflags=flags
    )
    set_status("正在启动 Agent…")
    threading.Thread(target=read_output, daemon=True).start()
    threading.Thread(target=wait_ready, args=(open_browser,), daemon=True).start()

def open_agent():
    if port_open(): webbrowser.open(APP_URL)
    else: start_agent(True)

def stop_agent():
    global process
    if process is not None and process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=5)
        except Exception:
            try: process.kill()
            except Exception: pass
    process = None
    set_status("Agent 已停止")

def on_close():
    if process is not None and process.poll() is None:
        if messagebox.askyesno("退出", "是否同时停止 Agent 后台服务？"):
            stop_agent()
    root.destroy()

root = tk.Tk()
root.title("AI Drive Manager")
root.geometry("720x500")
root.minsize(620, 430)

tk.Label(root, text="AI Drive Manager", font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=28, pady=(24,4))
tk.Label(root, text="一键启动 · Google Drive 自动连接 · 上传归档 · 快速查询",
         font=("Microsoft YaHei UI", 11), fg="#666").pack(anchor="w", padx=30, pady=(0,18))

status_var = tk.StringVar(value="正在检查 Agent 状态…")
status_label = tk.Label(root, textvariable=status_var, font=("Microsoft YaHei UI", 11, "bold"), anchor="w")
status_label.pack(fill="x", padx=30, pady=(0,12))

f = tk.Frame(root); f.pack(fill="x", padx=28, pady=(0,16))
tk.Button(f, text="启动并打开 Agent", font=("Microsoft YaHei UI", 11, "bold"), padx=18, pady=10,
          command=lambda: start_agent(True)).pack(side="left", padx=(0,10))
tk.Button(f, text="打开页面", padx=16, pady=10, command=open_agent).pack(side="left", padx=(0,10))
tk.Button(f, text="停止 Agent", padx=16, pady=10, command=stop_agent).pack(side="left")

tk.Label(root, text="正常使用：双击本软件 → 自动启动后台 → 自动打开浏览器。\n"
                    "已有 Google Drive 授权会复用 data/token.json，通常无需再次授权。\n"
                    "固定入口：http://localhost:8000",
         justify="left", font=("Microsoft YaHei UI", 9), fg="#555").pack(fill="x", padx=30, pady=(0,10))

logbox = tk.Text(root, height=13, font=("Consolas", 9), state="disabled", wrap="word")
logbox.pack(fill="both", expand=True, padx=28, pady=(0,24))

root.protocol("WM_DELETE_WINDOW", on_close)

if port_open():
    set_status("Agent 已运行 · 可查询和录入", True)
else:
    set_status("Agent 未启动")
    root.after(500, lambda: start_agent(True))

root.mainloop()
