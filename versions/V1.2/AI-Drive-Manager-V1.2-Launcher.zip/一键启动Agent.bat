@echo off
cd /d "%~dp0"
start "" pythonw "AI_Drive_Manager_Launcher.pyw"
